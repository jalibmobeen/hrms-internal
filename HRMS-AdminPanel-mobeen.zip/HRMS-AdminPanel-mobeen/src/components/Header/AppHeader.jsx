import React from "react";
import { Avatar } from "antd";
import { FaBars, FaAngleRight, FaUser } from "react-icons/fa6";
import { useSelector } from "react-redux";
import Dropdown from "react-bootstrap/Dropdown";
import { TfiAngleDown } from "react-icons/tfi";
import { PiUserBold } from "react-icons/pi";
import { IoCalendarOutline } from "react-icons/io5";
import { SlLock, SlLogout } from "react-icons/sl";
import { capitalizeFirstLetter, data_successfully } from "../../utils/helper";
import { ToastContainer } from "react-toastify";
import Button from "antd-button-color";
function AppHeader(props) {
  const { collapsed, setCollapsed, title } = props;
  const { path_name } = useSelector((state) => state.helper);

  return (
    <>
      <ToastContainer />
      <div className="flex justify-between items-center py-4 border-b-2 border-gray-50 px-4">
        <div className="flex items-center gap-3">
          <div>
            <Button
              type="primary"
              shape="circle"
              icon={collapsed ? <FaAngleRight /> : <FaBars />}
              onClick={() => setCollapsed(!collapsed)}
            />
          </div>
          <div>
            <h4 className="text-brand-100 font-bold text-base capitalize">
              {path_name === "/" ? (
                <>Dashboard</>
              ) : (
                <>{path_name.replace(/\//g, "")}</>
              )}
            </h4>
          </div>
        </div>
        <div>
          <Dropdown align="end" className="userDropdownMenu min-w-[180px]">
            <Dropdown.Toggle className="w-full bg-transparent border-0 text-gray-600 hover:text-gray-600 focus:text-gray-500 active:text-gray-600">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar
                    size="large"
                    className="bg-brand-100"
                    icon={<FaUser size={14} />}
                  />
                  <h4 className="text-gray-600 font-semibold text-[15px]">
                    {"user"}
                  </h4>
                </div>
                <div>
                  <TfiAngleDown size={14} />
                </div>
              </div>
            </Dropdown.Toggle>
            <Dropdown.Menu className="min-w-[250px] border-1 border-gray-100 drop-shadow-xl p-0 py-3 px-4">
              <div className="flex justify-start items-center gap-[15px]">
                <div>
                  <img
                    className="rounded-full h-12"
                    src={`https://ui-avatars.com/api/?name=${"User"}`}
                    alt=""
                  />
                </div>
                <div>
                  <h4 className="text-dark-100 font-semibold text-sm">
                    {capitalizeFirstLetter("User")}
                  </h4>
                  <p className="text-[12px] text-gray-500">-</p>
                </div>
              </div>
              <Dropdown.Divider className="border-gray-100 my-3 mb-2" />
              <Dropdown.Item
                className="p-2 rounded-lg transition-all"
                eventKey="1"
                onClick={() => console.log("hell")}
              >
                <div className="flex items-center gap-2 text-gray-600 hover:text-brand-100">
                  <div className="min-w-[24px]">
                    <PiUserBold size={18} />
                  </div>
                  <div className="text-[14px] font-medium">User profile</div>
                </div>
              </Dropdown.Item>
              <Dropdown.Item
                className="p-2 rounded-lg transition-all"
                eventKey="1"
                onClick={() => console.log("hell")}
              >
                <div className="flex items-center gap-2 text-gray-600 hover:text-brand-100">
                  <div className="min-w-[24px]">
                    <IoCalendarOutline size={18} />
                  </div>
                  <div className="text-[14px] font-medium">My Schedule</div>
                </div>
              </Dropdown.Item>
              <Dropdown.Item
                className="p-2 rounded-lg transition-all"
                eventKey="1"
                onClick={() => console.log("hell")}
              >
                <div className="flex items-center gap-2 text-gray-600 hover:text-brand-100">
                  <div className="min-w-[24px]">
                    <SlLock size={18} />
                  </div>
                  <div className="text-[14px] font-medium">Personal data</div>
                </div>
              </Dropdown.Item>
              <Dropdown.Divider className="border-gray-100 my-3 mb-2" />
              <Dropdown.Item
                className="p-2 rounded-lg transition-all hover:bg-red-100/30"
                eventKey="1"
              >
                <div className="flex items-center gap-2 text-red-400">
                  <div className="min-w-[24px]">
                    <SlLogout size={18} />
                  </div>
                  <div className="text-[14px] font-medium text-red-400">
                    Log out
                  </div>
                </div>
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
    </>
  );
}

export default AppHeader;
