import React, { useEffect, useState } from "react";
import { IoIosArrowDown } from "react-icons/io";
import { AiOutlineAntDesign } from "react-icons/ai";
import { FaAngleLeft } from "react-icons/fa6";
import { LuUser2 } from "react-icons/lu";
import { Button, Layout, Menu } from "antd";
import Logo from "./Logo";
import { UserAvater } from "../../components";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { on_changePath } from "../../store/slices/helper/Index";
import { capitalizeFirstLetter } from "../../utils/helper";
import { HomeIcon, MastersIcon, StaffIcon } from "../../utils/icon";

import {
  ContainerOutlined,
  BarsOutlined,
  AppstoreOutlined,
  MonitorOutlined,
  PartitionOutlined,
  BankOutlined,
  UngroupOutlined,
  GroupOutlined,
  TableOutlined,
  CreditCardOutlined,
  LineOutlined,
  BuildOutlined,
  CalendarOutlined,
  OneToOneOutlined,
  BorderOutlined,
  RobotOutlined,
} from "@ant-design/icons";
const { Sider } = Layout;
const { SubMenu } = Menu;

const items = [
  {
    label: "Dashboard",
    key: "/",
    icon: (
      <div className="w-[28px]">
        <img className="h-5" src={HomeIcon} alt="" />
      </div>
    ),
  },
  {
    label: "Staff Management",
    key: "SubMenu2",
    icon: (
      <div className="w-[28px]">
        <img className="h-6" src={StaffIcon} alt="" />
      </div>
    ),
    children: [
      {
        label: "Staff Listing",
        icon: <BarsOutlined style={{ fontSize: "20px" }} />,
        key: "/staff-listing",
      },
      {
        label: "Staff Document Listing",
        key: "/staff-document-listing",
        icon: <ContainerOutlined style={{ fontSize: "20px" }} />,
      },
    ],
  },
  {
    label: "Masters",
    key: "SubMenu3",
    icon: (
      <div className="w-[28px]">
        <img className="h-7" src={MastersIcon} alt="" />
      </div>
    ),
    children: [
      {
        label: "Department Master",
        icon: <AppstoreOutlined style={{ fontSize: "20px" }} />,
        key: "/1",
      },
      {
        label: "Position Master",
        key: "/position-master",
        icon: <MonitorOutlined style={{ fontSize: "20px" }} />,
      },
      {
        label: "Branch Master",
        key: "/3",
        icon: <PartitionOutlined style={{ fontSize: "20px" }} />,
      },
      {
        label: "Bank Master",
        key: "/4",
        icon: <BankOutlined style={{ fontSize: "20px" }} />,
      },
    ],
  },
  {
    label: "Announcement Masters",
    key: "/announcement-master",
    icon: (
      <div className="w-[28px]">
        <img className="h-7" src={MastersIcon} alt="" />
      </div>
    ),
  },

  {
    label: "Components",
    key: "SubMenu4",
    icon: <AiOutlineAntDesign style={{ fontSize: "27px" }} />,
    children: [
      {
        label: "Button",
        icon: <UngroupOutlined style={{ fontSize: "20px" }} />,
        key: "/component/button",
      },
      {
        label: "Form elements",
        icon: <GroupOutlined style={{ fontSize: "20px" }} />,
        key: "/component/form",
      },
      {
        label: "Table",
        icon: <TableOutlined style={{ fontSize: "20px" }} />,
        key: "/component/table",
      },
      {
        label: "Tab",
        icon: <CreditCardOutlined style={{ fontSize: "20px" }} />,
        key: "/component/tab",
      },
      {
        label: "Divider",
        icon: <LineOutlined style={{ fontSize: "20px" }} />,
        key: "/component/divider",
      },
      // {
      //   label: "Dropdown",
      //   icon: <BuildOutlined style={{ fontSize: "20px" }} />,
      //   key: "/staff-listing",
      // },
      // {
      //   label: "Calendar",
      //   icon: <CalendarOutlined style={{ fontSize: "20px" }} />,
      //   key: "/component/calendar",
      // },
      {
        label: "Carousel",
        icon: <OneToOneOutlined style={{ fontSize: "20px" }} />,
        key: "/component/carousel",
      },
      {
        label: "Empty",
        icon: <BorderOutlined style={{ fontSize: "20px" }} />,
        key: "/component/empty",
      },
      // {
      //   label: "Modal",
      //   icon: <RobotOutlined style={{ fontSize: "20px" }} />,
      //   key: "/staff-listing",
      // },
    ],
  },
  // {
  //   label: "Components",
  //   key: "/component",
  //   icon: <AiOutlineAntDesign size={30} />,
  // },
];
function Index(props) {
  const dispatch = useDispatch();
  const [collapsedWidthMain, setcollapsedWidthMain] = useState(80);
  const [mobileSideToggle, setmobileSideToggle] = useState(false);
  const { collapsed, setCollapsed, responsiveSide, setresponsiveSide } = props;
  const navigate = useNavigate();
  useEffect(() => {
    dispatch(on_changePath(window.location.pathname));
  }, []);
  const onClick = (e) => {
    dispatch(on_changePath(e.key));
    navigate(e.key);
  };

  return (
    <>
      <Sider
        breakpoint="lg"
        collapsedWidth={collapsedWidthMain}
        width={300}
        onBreakpoint={(broken) => {
          if (broken) {
            setcollapsedWidthMain(0);
            setresponsiveSide(broken);
            setmobileSideToggle(true);
          } else {
            setcollapsedWidthMain(80);
            setresponsiveSide(broken);
            setmobileSideToggle(false);
          }
        }}
        onCollapse={(collapsed, type) => {
          setCollapsed(collapsed);
        }}
        trigger={null}
        collapsible
        collapsed={collapsed}
        style={{
          height: "100vh",
          position: "fixed",
          left: 0,
          top: 0,
          bottom: 0,
        }}
      >
        <div>
          {mobileSideToggle && !collapsed && (
            <div
              onClick={() => setCollapsed(!collapsed)}
              className="fixed top-3 -right-[20px]"
            >
              <Button
                size="large"
                type="primary"
                color="white"
                shape="circle"
                icon={<FaAngleLeft />}
                onClick={() => setCollapsed(!collapsed)}
                className="shadow-xl bg-white text-brand-100 outline-none focus:!outline-none hover:!text-brand-100"
              />
            </div>
          )}
          {/* for logo */}
          <div className="demo-logo-vertical">
            <Logo />
          </div>
          {/* user avtar */}
          <div className="px-3 py-4">
            <UserAvater
              name={capitalizeFirstLetter("-")}
              collapsed={collapsed}
            />
          </div>
          <Menu
            className="sidebarMenuWrapper"
            mode="inline"
            defaultSelectedKeys={[window.location.pathname]}
            items={items}
            onClick={onClick}
            forceSubMenuRender={true}
            expandIcon={<IoIosArrowDown />}
          />
        </div>
      </Sider>
    </>
  );
}

export default Index;
