import React from "react";
import { LogoIcon } from "../../utils/icon";

function Logo() {
  return (
    <div className="px-3 pt-4">
      <a href="/">
        <img className="rounded-full" src="https://placehold.co/60x60" alt="" />
      </a>
    </div>
  );
}

export default Logo;
