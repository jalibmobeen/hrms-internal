import React from "react";
import { Avatar } from "antd";
import { FaUser } from "react-icons/fa6";

function UserAvater(props) {
  const { collapsed } = props;
  return (
    <>
      <div className="flex gap-3 items-center">
        <Avatar
          size="large"
          style={{
            color: "#fff",
            fontSize: "13px",
          }}
          icon={<FaUser />}
          className="bg-gradient"
        ></Avatar>
        {!collapsed && (
          <div className="info">
            <p className="text-brand-100 text-[15px]">
              Welcome <span className="font-bold">Admin</span>
            </p>
          </div>
        )}
      </div>
    </>
  );
}

export default UserAvater;
