import { Input } from "antd";
import React, { useState } from "react";
import { IoSearchSharp } from "react-icons/io5";
function GlobalFilter({ filter, setFilter }) {
  return (
    <>
      <Input
        placeholder="Search record"
        prefix={<IoSearchSharp size={20} color="#B5B5B5" />}
        className="text-sm font-medium text-gray-700 placeholder:!text-gray-900 max-w-[300px]"
        value={filter || ""}
        onChange={(e) => setFilter(e.target.value)}
        allowClear={true}
      />
      {/* <input
        className="border"
        placeholder="Search..."
        value={filter || ""}
        onChange={(e) => setFilter(e.target.value)}
      /> */}
    </>
  );
}

export default GlobalFilter;
