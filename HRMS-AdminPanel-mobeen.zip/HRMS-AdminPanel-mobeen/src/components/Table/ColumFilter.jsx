import { Input, Select } from "antd";
import React, { useMemo } from "react";
import { LiaAngleDownSolid } from "react-icons/lia";

function ColumFilter({ column }) {
  const { filterValue, setFilter, preFilteredRows, id } = column;

  const options = React.useMemo(() => {
    const options = new Set();
    preFilteredRows.forEach((row) => {
      options.add(row.values[id]);
    });
    return [...options.values()];
  }, [id, preFilteredRows, filterValue]);

  return (
    <>
      {column.filterType === "input" && (
        // <input
        //   onClick={(e) => e.stopPropagation()}
        //   className="border w-20"
        //   placeholder="Search..."
        //   value={filterValue || ""}
        //   onChange={(e) => setFilter(e.target.value)}
        // />

        <Input
          size="large"
          placeholder={`Filter ${column.Header}`}
          className="text-[14px] font-medium text-gray-700 placeholder:!text-gray-900 max-w-[100%]"
          allowClear={true}
          value={filterValue || ""}
          onChange={(e) => setFilter(e.target.value)}
        />
      )}
      {column.filterType === "select" && (
        <select
          className="border"
          onClick={(e) => e.stopPropagation()}
          value={filterValue || ""}
          onChange={(e) => setFilter(e.target.value || undefined)}
        >
          <option value="">All</option>
          {options.map((option, i) => (
            <option key={i} value={option}>
              {option}
            </option>
          ))}
        </select>
        // <Select
        //   size="large"
        //   placeholder="Select status"
        //   className="tableCustomSelect"
        //   suffixIcon={<LiaAngleDownSolid />}
        //   allowClear={true}
        //   // Value={filterValue || ""}
        //   onChange={(e) => setFilter(e)}
        //   options={[
        //     { value: "", label: "All" }, // Default option
        //     { value: "Active", label: "Active" }, // Default option
        //     { value: "no", label: "Inactive" }, // Default option
        //     // ...options.map((option, i) => ({
        //     //   value: option,
        //     //   label: option,
        //     // })),
        //   ]}
        // />
      )}
    </>
  );
}

export default ColumFilter;
