import React, { useMemo } from "react";
import {
  usePagination,
  useTable,
  useSortBy,
  useGlobalFilter,
  useFilters,
} from "react-table";
import MOCK_DATA from "./MOCK_DATA.json";
import { COLUMNS } from "./colums";
import { Button, Empty, List, Select, Skeleton } from "antd";
import TablePagination from "./TablePagination";
import { FaSort, FaSortDown, FaSortUp } from "react-icons/fa";
import { LiaAngleDownSolid } from "react-icons/lia";
import GlobalFilter from "./GlobalFilter";
import ColumFilter from "./ColumFilter";

function MasterTable(props) {
  const { loading, tableHead, TableData, sorting, globalSearch } = props;

  // memo use
  const columns = useMemo(() => tableHead, [TableData]);
  const data = useMemo(() => TableData, [TableData]);
  const defaultColumn = useMemo(() => {
    return {
      Filter: ColumFilter,
      filterType: "input",
    };
  }, []);
  // hooks
  const tableInstance = useTable(
    {
      columns,
      data,
      defaultColumn,
    },
    useGlobalFilter,
    useFilters,
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    rows,
    prepareRow,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    state,
    gotoPage,
    pageCount,
    setPageSize,
    setGlobalFilter,
  } = tableInstance;

  const { pageIndex, pageSize, globalFilter } = state;
  // global filter no data found UI
  const filteredData = useMemo(() => {
    return rows.filter((row) => {
      // Perform filtering based on the global filter value
      return Object.values(row.values).some((value) =>
        String(value).toLowerCase().includes(String(globalFilter).toLowerCase())
      );
    });
  }, [globalFilter, rows]);

  return (
    <>
      {globalSearch && (
        <div className="flex justify-end mb-3">
          <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
        </div>
      )}
      <div className="table-responsive masterTable customScroll">
        <table {...getTableProps()} className="table leading-normal min-w-full">
          <thead>
            {headerGroups.map((headerGroup, index) => (
              <tr key={index} {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column, columnIndex) => (
                  <th
                    className="text-sm font-semibold text-gray-600 relative"
                    key={columnIndex}
                    {...column.getHeaderProps(
                      sorting ? column.getSortByToggleProps() : {}
                    )}
                  >
                    {column.render("Header")}
                    {sorting && (
                      <span className="absolute right-0 top-[10px]">
                        {column.isSorted ? (
                          column.isSortedDesc ? (
                            <FaSortDown />
                          ) : (
                            <FaSortUp />
                          )
                        ) : (
                          <FaSort />
                        )}
                      </span>
                    )}
                    <div className="mt-2 mb-2">
                      {column.canFilter ? column.render("Filter") : null}
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          {data.length > 0 && (
            <>
              {filteredData.length > 0 ? (
                <>
                  {!loading ? (
                    <tbody {...getTableBodyProps()}>
                      {page.map((row, rowIndex) => {
                        prepareRow(row);
                        return (
                          <tr key={rowIndex} {...row.getRowProps()}>
                            {row.cells.map((cell, cellIndex) => {
                              return (
                                <td key={cellIndex} {...cell.getCellProps()}>
                                  {cell.column.id === "StatusCode"
                                    ? row.values.StatusCode === "Active"
                                      ? "Active"
                                      : "Inactive"
                                    : cell.render("Cell")}
                                  {/* {cell.render("Cell")} */}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  ) : (
                    <>
                      <tbody>
                        <tr>
                          <td colSpan={8} className="!py-10">
                            <Skeleton
                              className="w-full"
                              round={true}
                              avatar={false}
                              active
                            />
                            <Skeleton
                              className="w-full mt-4"
                              round={true}
                              avatar={false}
                              active
                            />
                            <Skeleton
                              className="w-full mt-4"
                              round={true}
                              avatar={false}
                              active
                            />
                          </td>
                        </tr>
                      </tbody>
                    </>
                  )}
                </>
              ) : (
                <tr>
                  <td colSpan={columns.length}>
                    <Empty />
                  </td>
                </tr>
              )}
            </>
          )}
        </table>
      </div>
      {!data.length > 0 && (
        <>
          <Empty />
        </>
      )}
      {data.length > 0 && (
        <>
          <div className="flex items-center mt-4 gap-3">
            <div>
              <h4 className="text-dark-100 text-sm font-medium">
                Record Per Page
              </h4>
            </div>
            <div>
              <Select
                size="small"
                placeholder="Select page size"
                className="min-w-[100px] min-h-[35px]"
                suffixIcon={<LiaAngleDownSolid />}
                defaultValue={pageSize || ""}
                Value={pageSize || ""}
                onChange={(val) => setPageSize(Number(val))}
                options={[10, 25, 50].map((option) => ({
                  value: option,
                  label: option,
                }))}
              />
            </div>
          </div>
          <div className="mt-3 flex justify-between items-center flex-wrap">
            <div className="min-w-[200px]">
              <h4 className="text-dark-100 text-sm font-medium">
                Page Number {pageIndex + 1}
              </h4>
            </div>
            <div className="min-w-[200px]">
              <TablePagination
                totalItems={filteredData.length}
                pageSize={pageSize}
                onPageChange={(e) => gotoPage(e - 1)}
                currentPage={pageIndex + 1}
              />
            </div>
            <div className="min-w-[200px]">
              <h4 className="text-dark-100 text-sm font-medium text-end">
                Showing {pageIndex + 1} of {pageOptions.length} records
              </h4>
            </div>
          </div>
          {/* <div className="mt-3">
            <Button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
              {"<<"}
            </Button>
            <Button
              type="primary"
              onClick={() => previousPage()}
              disabled={!canPreviousPage}
            >
              Previous
            </Button>
            <Button onClick={() => nextPage()} disabled={!canNextPage}>
              Next
            </Button>
            <Button
              onClick={() => gotoPage(pageCount - 1)}
              disabled={!canNextPage}
            >
              {">>"}
            </Button>
          </div> */}
        </>
      )}
    </>
  );
}

export default MasterTable;
