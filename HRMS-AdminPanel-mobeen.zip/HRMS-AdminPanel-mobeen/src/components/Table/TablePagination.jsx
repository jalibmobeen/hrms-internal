import React from "react";
import { Pagination } from "antd";
function TablePagination({ totalItems, pageSize, currentPage, onPageChange }) {
  const handlePageChange = (page) => {
    onPageChange(page);
  };
  return (
    <>
      <Pagination
        total={totalItems}
        pageSize={pageSize}
        current={currentPage}
        onChange={handlePageChange}
        showSizeChanger={false} // Hide size changer
        showLessItems={true}
        className="border rounded-full py-1 px-2 border-gray-100"
      />
    </>
  );
}

export default TablePagination;
