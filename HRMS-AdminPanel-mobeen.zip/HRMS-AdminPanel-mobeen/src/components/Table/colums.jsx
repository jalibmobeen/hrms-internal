import { Button } from "antd";
import { format } from "date-fns";
import { AiOutlineEye } from "react-icons/ai";
import { GoPencil } from "react-icons/go";
import { FaRegTrashCan } from "react-icons/fa6";

const ActionsCell = ({ row }) => {
  const handleAction = () => {
    // Define the action to be performed when the button is clicked
    console.log("Action clicked for row:", row);
  };

  return (
    <>
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<AiOutlineEye size={20} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<GoPencil size={17} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton hover:!text-red-600"
        shape="circle"
        icon={<FaRegTrashCan size={15} />}
        onClick={handleAction}
      />
    </>
  );
};

export const COLUMNS = [
  {
    Header: "Id",
    accessor: "id",
    disableFilters: true,
  },
  {
    Header: "First name",
    accessor: "first_name",
  },
  {
    Header: "Last name",
    accessor: "last_name",
  },
  {
    Header: "Email",
    accessor: "email",
  },
  {
    Header: "Country",
    accessor: "Country",
  },
  {
    Header: "Phone",
    accessor: "Phone",
  },
  {
    Header: "Status",
    accessor: "status",
    filterType: "select",
  },
  {
    Header: "Actions",
    Cell: ({ row }) => <ActionsCell row={row} />,
  },
];
