import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
const initialState = {
  loading: false,
  data: [],
};
// test

const DemoSlice = createSlice({
  name: "demo-test",
  initialState,
  extraReducers: {},
  reducers: {},
});
const { reducer } = DemoSlice;

export const {} = DemoSlice.actions;
export default reducer;
