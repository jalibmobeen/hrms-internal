import { createSlice } from "@reduxjs/toolkit";
import {
  getPositions,
  resetPassword,
  verifyOtp,
  addPosition,
  forgotPassword,
} from "./userApi";

export const userSlice = createSlice({
  name: "user",
  initialState: {
    token:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6WyJ7XCJJZFwiOjEsXCJVc2VyTmFtZVwiOlwiYWRtaW5cIixcIk5hbWVcIjpcImFkbWluXCIsXCJVc2VyUGFzc3dvcmRcIjpcIkFkbTEyMzQ1Nm5cIixcIkVtYWlsQWRkcmVzc1wiOlwiYWRtaW5AYWRtaW4uY29tXCIsXCJQaG9uZVwiOlwiMTIzXCIsXCJSZW1hcmtzXCI6XCJcIixcIkFjY2Vzc1Rva2VuXCI6XCJcIixcIlVzZXJSb2xlXCI6XCJBZG1pblwiLFwiTG9nSW5PblwiOlwiMjAyNC0wNi0yMFQyMTo0NzoxNy43NFwiLFwiQ3JlYXRlZEJ5XCI6MSxcIkNyZWF0ZWRPblwiOlwiMjAyNC0wNi0yMFQyMTo0NzoxNy43NFwiLFwiTW9kaWZpZWRCeVwiOjEsXCJNb2RpZmllZE9uXCI6XCIyMDI0LTA2LTIwVDIxOjQ3OjE3Ljc0XCIsXCJTdGF0dXNDb2RlXCI6XCJBY3RpdmVcIixcIklzRGVsZXRlZFwiOmZhbHNlfSIsIkN1c3RvbU9iamVjdENhbkJlQWRkZWRIZXJlIl0sIm5iZiI6MTcxOTE0MDI2NywiZXhwIjoxNzE5NzQ1MDY3LCJpYXQiOjE3MTkxNDAyNjd9.qtC2OTyHTgQ8ngXb6uzybrFmjVPHnpMhKBxu_pjKV-0",
    // token: null,
    loading: "idle",
    email: "",
    otp: "",
    error: null,
  },
  reducers: {
    customLogout: (state) => {
      state.token = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(forgotPassword.pending, (state) => {
        state.loading = "pending";
      })
      .addCase(forgotPassword.fulfilled, (state, action) => {
        state.loading = "succeeded";
        state.email = action.payload.email;
      })
      .addCase(forgotPassword.rejected, (state) => {
        state.loading = "failed";
      })
      .addCase(verifyOtp.pending, (state) => {
        state.loading = "pending";
      })
      .addCase(verifyOtp.fulfilled, (state, action) => {
        state.loading = "succeeded";
        state.otp = action.payload.otp;
      })
      .addCase(verifyOtp.rejected, (state) => {
        state.loading = "failed";
      })
      .addCase(resetPassword.pending, (state) => {
        state.loading = "pending";
      })
      .addCase(resetPassword.fulfilled, (state) => {
        state.loading = "succeeded";
        state.otp = "";
        state.email = "";
      })
      .addCase(resetPassword.rejected, (state) => {
        state.loading = "failed";
      })
      .addCase(getPositions.pending, (state) => {
        state.loading = "pending";
      })
      .addCase(getPositions.fulfilled, (state) => {
        state.loading = "succeeded";
      })
      .addCase(getPositions.rejected, (state) => {
        state.loading = "failed";
      })
      .addCase(addPosition.pending, (state) => {
        state.loading = "pending";
      })
      .addCase(addPosition.fulfilled, (state) => {
        state.loading = "succeeded";
      })
      .addCase(addPosition.rejected, (state) => {
        state.loading = "failed";
      });
  },
});

export const { customLogout } = userSlice.actions;

export default userSlice.reducer;
