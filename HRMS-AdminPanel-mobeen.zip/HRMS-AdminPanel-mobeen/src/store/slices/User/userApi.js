import { toast } from "react-toastify";
import axiosInstance from "../../interceptor";
import { createAsyncThunk } from "@reduxjs/toolkit";

export const forgotPassword = createAsyncThunk(
  "forgotPassword",
  async ({ apiEndpoint, requestData, email }, thunkAPI) => {
    try {

      await axiosInstance.post(apiEndpoint, requestData);
      return {email};
    } catch (error) {
      return thunkAPI.rejectWithValue(error?.response?.data);
    }
  }
);

export const verifyOtp = createAsyncThunk(
  "verifyOtp",
  async ({ apiEndpoint, requestData, otp }, thunkAPI) => {
    try {

      await axiosInstance.post(apiEndpoint, requestData);
      return {otp};
    } catch (error) {
      return thunkAPI.rejectWithValue(error?.response?.data);
    }
  }
);

export const resetPassword = createAsyncThunk(
  "resetPassword",
  async ({ apiEndpoint, requestData, otp }, thunkAPI) => {
    try {

      await axiosInstance.post(apiEndpoint, requestData);
      return {otp};
    } catch (error) {
      return thunkAPI.rejectWithValue(error?.response?.data);
    }
  }
);

export const getPositions = createAsyncThunk(
  "getPositions",
  async ({ apiEndpoint }, thunkAPI) => {
    try {

      const response = await axiosInstance.get(apiEndpoint);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error?.response?.data);
    }
  }
);

export const addPosition = createAsyncThunk(
  "addPosition",
  async ({ apiEndpoint, requestData }, thunkAPI) => {
    try {
      const response = await axiosInstance.post(apiEndpoint, requestData);
      return response.data;
    } catch (error) {
      console.log(error)
      toast.error(error.response.data.document)
      return thunkAPI.rejectWithValue(error?.response?.data);
    }
  }
);