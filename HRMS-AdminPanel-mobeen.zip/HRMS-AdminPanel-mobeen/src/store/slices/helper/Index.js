import { createSlice } from "@reduxjs/toolkit";
const initialState = {
  loading: false,
  path_name: "/",
};
const HelperSlice = createSlice({
  name: "helper-slice",
  initialState,
  extraReducers: {},
  reducers: {
    on_changePath: (state, action) => {
      state.path_name = action.payload;
    },
  },
});
const { reducer } = HelperSlice;

export const { on_changePath } = HelperSlice.actions;
export default reducer;
