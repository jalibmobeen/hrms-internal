import { configureStore } from "@reduxjs/toolkit";
import DemoSlice from "./slices/demo/demo";
import HelperSlice from "./slices/helper/Index";
import userSlice from "./slices/User/userSlice";

const reducer = {
  demo: DemoSlice,
  helper: HelperSlice,
  user: userSlice,
};

export const store = configureStore({
  reducer: reducer,
  devTools: true,
});

export default store;
