import { PlusOutlined } from "@ant-design/icons";
import { Card } from "antd";
import Button from "antd-button-color";
import React from "react";
import { MasterTable } from "../../components";
import { COLUMNS } from "./helper/colums";
import MockData from "./helper/MOCK_DATA.json";
function StaffListing() {
  return (
    <>
      <Card
        bordered={false}
        className="bg-white py-2 px-2 cardHeaderBorderNone"
        extra={
          <>
            <Button
              className="min-w-[180px] border !border-[#D5D5D5]"
              type="secondary"
              icon={<PlusOutlined />}
            >
              Add staff
            </Button>
          </>
        }
      >
        <MasterTable loading={false} tableHead={COLUMNS} TableData={MockData} />
      </Card>
    </>
  );
}

export default StaffListing;
