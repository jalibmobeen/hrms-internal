import { Button } from "antd";
import { format } from "date-fns";
import { AiOutlineEye } from "react-icons/ai";
import { GoPencil } from "react-icons/go";
import { FaRegTrashCan } from "react-icons/fa6";

const ActionsCell = ({ row }) => {
  const handleAction = () => {
    // Define the action to be performed when the button is clicked
    console.log("Action clicked for row:", row);
  };

  return (
    <>
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<AiOutlineEye size={20} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<GoPencil size={17} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton hover:!text-red-600"
        shape="circle"
        icon={<FaRegTrashCan size={15} />}
        onClick={handleAction}
      />
    </>
  );
};

export const COLUMNS = [
  {
    Header: "#",
    accessor: "id",
    disableFilters: true,
  },
  {
    Header: "Name",
    accessor: "name",
  },
  {
    Header: "IC No.",
    accessor: "IC_No",
  },
  {
    Header: "Nationality",
    accessor: "nationality",
  },
  {
    Header: "Passport No.",
    accessor: "passport_no",
  },
  {
    Header: "IC Expiry",
    accessor: "IC_expiry",
  },
  {
    Header: "LD Expiry",
    accessor: "LD_expiry",
  },
  {
    Header: "Visa Expiry",
    accessor: "Visa_expiry",
  },
  {
    Header: "Position",
    accessor: "position",
  },
  {
    Header: "Insurance",
    accessor: "insurance",
  },
  {
    Header: "Contract Expiry",
    accessor: "contract_expiry",
  },
  {
    Header: "Medical Expiry",
    accessor: "medical_expiry",
  },
  {
    Header: "Driving License Expiry",
    accessor: "driving_license_expiry",
  },
  {
    Header: "Actions",
    Cell: ({ row }) => <ActionsCell row={row} />,
  },
];
