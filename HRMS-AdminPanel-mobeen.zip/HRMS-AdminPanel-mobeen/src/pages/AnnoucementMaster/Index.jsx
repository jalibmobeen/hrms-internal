import { Card, DatePicker, Form, Input, Select, Space } from "antd";
import React from "react";
const { TextArea } = Input;
import { MasterTable } from "../../components";
import { COLUMNS } from "./helper/colums";
import MockData from "./helper/MOCK_DATA.json";

function Index() {
  const submitForm = (data) => {
    console.log(data);
  };
  return (
    <>
      <Card bordered={false} className="bg-white py-2 px-2">
        <Form name="basic" onFinish={submitForm}>
          <Form.Item>
            {/* <Input
              className="inputWithPrefix"
              prefix="Announcement Date"
              placeholder="Select date"
            /> */}
            <div className="w-full">
              <Space.Compact className="w-full">
                <Input
                  defaultValue="Announcement Date"
                  readOnly
                  className="min-w-[30%] max-w-[30%] border-r-0"
                />
                <DatePicker
                  placeholder="Announcement Date"
                  className="w-full border-l-0"
                />
              </Space.Compact>
            </div>
          </Form.Item>
          <Form.Item>
            <Input
              className="inputWithPrefix"
              prefix="Announcement Title"
              placeholder="Enter title"
            />
          </Form.Item>
          <Form.Item>
            <div className="w-full">
              <Space.Compact className="w-full">
                <Input
                  defaultValue="Choose Employee Type"
                  readOnly
                  className="min-w-[30%] max-w-[30%] border-r-0"
                />
                <Select
                  mode="tags"
                  placeholder="Select employees type"
                  onChange={(e) => console.log(e)}
                  className="!border-l-0 border-r-0"
                  options={[
                    {
                      value: "jack",
                      label: "Jack",
                    },
                    {
                      value: "lucy",
                      label: "Lucy",
                    },
                    {
                      value: "Yiminghe",
                      label: "yiminghe",
                    },
                    {
                      value: "disabled",
                      label: "Disabled",
                      disabled: true,
                    },
                  ]}
                />
                <Input
                  defaultValue="(Multi-select)"
                  readOnly
                  className="min-w-[20%] max-w-[20%] !border-l-0 border-r-0 text-end"
                />
              </Space.Compact>
            </div>
          </Form.Item>
          <Form.Item>
            <div className="w-full">
              <Space.Compact className="w-full">
                <Input
                  defaultValue="Employees"
                  readOnly
                  className="min-w-[30%] max-w-[30%] border-r-0"
                />
                <Select
                  mode="tags"
                  placeholder="Select employees"
                  onChange={(e) => console.log(e)}
                  className="!border-l-0"
                  options={[
                    {
                      value: "shisir",
                      label: "Nimat Tajudeen",
                    },
                    {
                      value: "lucy",
                      label: "mushaf@swishsols.com",
                    },
                    {
                      value: "demo",
                      label: "demo user name",
                    },
                  ]}
                />
              </Space.Compact>
            </div>
          </Form.Item>
          <Form.Item>
            <TextArea
              className="dark-place"
              placeholder="Announcement"
              autoSize={{
                minRows: 4,
                maxRows: 6,
              }}
            />
          </Form.Item>
        </Form>
        <div className="mt-10">
          <MasterTable
            globalSearch={false}
            loading={false}
            tableHead={COLUMNS}
            TableData={MockData}
          />
        </div>
      </Card>
    </>
  );
}

export default Index;
