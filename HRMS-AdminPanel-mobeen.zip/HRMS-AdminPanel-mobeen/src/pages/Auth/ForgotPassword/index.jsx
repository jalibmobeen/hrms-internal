import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { Input, Button, Form as AntForm } from "antd";
import { Container, Row, Col } from "react-bootstrap";
import { forgotPassword } from "../../../store/slices/User/userApi";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const { Item: FormItem } = AntForm;

const validationSchema = Yup.object({
  EmailId: Yup.string()
    .email("Invalid email address")
    .required("Email is required"),
});

const ForgotPassword = () => {

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {loading} = useSelector((state) => state.user)

  const handleSubmit = (values) => {
    const data = {
      apiEndpoint: "/v1/api/resetpasswordsendotp",
      requestData: JSON.stringify(values),
      email: values.EmailId,
    };
    dispatch(forgotPassword(data)).then((res) => {
      if (res.type === "forgotPassword/fulfilled") {
        toast.success("OTP has been send to email");
        navigate("/verify-otp");
      }
    });
  };

  return (
    <Container
      fluid
      className="vh-100 d-flex justify-content-center align-items-center"
    >
      <Row className="w-100">
        <Col xs={12} md={6} lg={4} className="mx-auto">
          <h1 className="text-center mb-5 fw-bold fs-2">Forgot Password</h1>
          <Formik
            initialValues={{ EmailId: "" }}
            validationSchema={validationSchema}
            onSubmit={(values) => {
              console.log(values);
              // setSubmitting(false);
              handleSubmit(values);
            }}
          >
            {({ errors, touched, handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <FormItem
                  label="Email"
                  validateStatus={
                    errors.EmailId && touched.EmailId ? "error" : ""
                  }
                  help={errors.EmailId && touched.EmailId ? errors.EmailId : ""}
                >
                  <Field name="EmailId">
                    {({ field }) => (
                      <Input {...field} className="custom-input" />
                    )}
                  </Field>
                </FormItem>
                <FormItem className="text-center">
                  <Button className="w-100" type="primary" htmlType="submit" disabled={loading === "pending" ? true : false}>
                    {loading === "pending" ? "Loading..." : "Send"}
                  </Button>
                </FormItem>
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default ForgotPassword;
