import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { Input, Button, Form as AntForm } from "antd";
import { Container, Row, Col } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { resetPassword } from "../../../store/slices/User/userApi";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const { Item: FormItem } = AntForm;

const validationSchema = Yup.object({
  newPassword: Yup.string()
    .min(8, "Password must be at least 8 characters")
    .required("New password is required"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("newPassword"), null], "Passwords must match")
    .required("Confirm password is required"),
});

const ResetPassword = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, email, otp } = useSelector((state) => state.user);

  const handleSubmit = (values) => {
    const data = {
      apiEndpoint: "/v1/api/resetpassword",
      requestData: JSON.stringify({ ...values, EmailId: email, OTP: otp }),
      email: values.EmailId,
    };
    dispatch(resetPassword(data)).then((res) => {
      if (res.type === "resetPassword/fulfilled") {
        navigate("/");
        toast.success("New password has been set");
      }
    });
  };

  return (
    <Container
      fluid
      className="vh-100 d-flex justify-content-center align-items-center"
    >
      <Row className="w-100">
        <Col xs={12} md={6} lg={4} className="mx-auto">
          <h1 className="text-center mb-5 fw-bold fs-2">Reset Password</h1>
          <Formik
            initialValues={{ newPassword: "", confirmPassword: "" }}
            validationSchema={validationSchema}
            onSubmit={(values) => {
              handleSubmit(values);
            }}
          >
            {({ errors, touched, handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <FormItem
                  label="New Password"
                  validateStatus={
                    errors.newPassword && touched.newPassword ? "error" : ""
                  }
                  help={
                    errors.newPassword && touched.newPassword
                      ? errors.newPassword
                      : ""
                  }
                >
                  <Field name="newPassword">
                    {({ field }) => (
                      <Input.Password {...field} className="custom-input" />
                    )}
                  </Field>
                </FormItem>
                <FormItem
                  label="Confirm Password"
                  validateStatus={
                    errors.confirmPassword && touched.confirmPassword
                      ? "error"
                      : ""
                  }
                  help={
                    errors.confirmPassword && touched.confirmPassword
                      ? errors.confirmPassword
                      : ""
                  }
                >
                  <Field name="confirmPassword">
                    {({ field }) => (
                      <Input.Password {...field} className="custom-input" />
                    )}
                  </Field>
                </FormItem>
                <FormItem className="text-center">
                  <Button
                    type="primary"
                    htmlType="submit"
                    className="w-100"
                    disabled={loading === "pending" ? true : false}
                  >
                    {loading === "pending" ? "Loading..." : "Send"}
                  </Button>
                </FormItem>
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default ResetPassword;
