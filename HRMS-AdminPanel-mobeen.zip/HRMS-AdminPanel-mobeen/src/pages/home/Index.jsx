import React from "react";

function Index() {
  return <div>I am dashboard page</div>;
}

export default Index;
