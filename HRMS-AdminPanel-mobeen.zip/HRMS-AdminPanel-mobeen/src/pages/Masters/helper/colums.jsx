import { Button } from "antd";
import { AiOutlineEye } from "react-icons/ai";
import { GoPencil } from "react-icons/go";
import { FaRegTrashCan } from "react-icons/fa6";

const ActionsCell = ({ row }) => {
  const handleAction = () => {
    console.log("Action clicked for row:", row);
  };

  return (
    <>
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<AiOutlineEye size={20} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton"
        shape="circle"
        icon={<GoPencil size={17} />}
        onClick={handleAction}
      />
      <Button
        className="tableActionButton hover:!text-red-600"
        shape="circle"
        icon={<FaRegTrashCan size={15} />}
        onClick={handleAction}
      />
    </>
  );
};

export const COLUMNS = [
  {
    Header: "#",
    accessor: "id",
    disableFilters: true,
  },
  {
    Header: "PositionID",
    accessor: "PositionID",
  },
  {
    Header: "PositionName",
    accessor: "PositionName",
  },
  {
    Header: "DepartmentID",
    accessor: "DepartmentID",
  },
  {
    Header: "BasicSalary",
    accessor: "BasicSalary",
  },
  {
    Header: "ContractTemplatePath",
    accessor: "ContractTemplatePath",
  },
  {
    Header: "FirstHikePeriod",
    accessor: "FirstHikePeriod",
  },
  {
    Header: "FirstHikeAmount",
    accessor: "FirstHikeAmount",
  },
  {
    Header: "SecondHikePeriod",
    accessor: "SecondHikePeriod",
  },
  {
    Header: "SecondHikeAmount",
    accessor: "SecondHikeAmount",
  },
  {
    Header: "ThirdHikePeriod",
    accessor: "ThirdHikePeriod",
  },
  {
    Header: "ThirdHikeAmount",
    accessor: "ThirdHikeAmount",
  },
  {
    Header: "StatusCode",
    accessor: "StatusCode",
  },
  {
    Header: "Actions",
    Cell: ({ row }) => <ActionsCell row={row} />,
  },
];
