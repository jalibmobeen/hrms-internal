import { Card } from "antd";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { Input, Button, Select, Form as AntForm } from "antd";
import { Container, Row, Col } from "react-bootstrap";
import FormItem from "antd/es/form/FormItem";
import { useDispatch, useSelector } from "react-redux";
import { addPosition } from "../../store/slices/User/userApi";
import { toast } from "react-toastify";

const AddPosItionMaster = () => {
  const { Option } = Select;
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.user);

  const validationSchema = Yup.object({
    PositionID: Yup.string().required("Position ID is required"),
    PositionName: Yup.string().required("Position Name is required"),
    DepartmentID: Yup.string().required("Department ID is required"),
    BasicSalary: Yup.number().required("Basic Salary is required"),
    ContractTemplatePath: Yup.string().required(
      "Contract Template Path is required"
    ),
    FirstHikePeriod: Yup.number().required("First Hike Period is required"),
    FirstHikeAmount: Yup.number().required("First Hike Amount is required"),
    SecondHikePeriod: Yup.number().required("Second Hike Period is required"),
    SecondHikeAmount: Yup.number().required("Second Hike Amount is required"),
    ThirdHikePeriod: Yup.number().required("Third Hike Period is required"),
    ThirdHikeAmount: Yup.number().required("Third Hike Amount is required"),
    StatusCode: Yup.string().required("Status Code is required"),
  });

  const handleSubmit = (values, resetForm) => {
    console.log(values);
    const data = {
      apiEndpoint: "/v1/api/Positions",
      requestData: JSON.stringify({
        ...values,
        CreatedBy: "12",
        CreatedOn: "06/22/2024",
        ModifiedBy: "",
        ModifiedOn: "",
      }),
    };
    dispatch(addPosition(data)).then((res) => {
      if (res.type === "addPosition/fulfilled") {
        toast.success("Position created");
        resetForm();
      }
    });
  };

  return (
    <>
      <Card
        bordered={false}
        className="bg-white py-2 px-2 cardHeaderBorderNone"
      >
        <Container
          fluid
          className="d-flex justify-content-center align-items-center"
        >
          <Row className="w-100">
            <Col xs={12} md={10} lg={10} className="mx-auto">
              <h1 className="text-center mb-5 fw-bold fs-2">
                Add Position Form
              </h1>
              <Formik
                initialValues={{
                  PositionID: "",
                  PositionName: "",
                  DepartmentID: "",
                  BasicSalary: "",
                  ContractTemplatePath: "",
                  FirstHikePeriod: "",
                  FirstHikeAmount: "",
                  SecondHikePeriod: "",
                  SecondHikeAmount: "",
                  ThirdHikePeriod: "",
                  ThirdHikeAmount: "",
                  StatusCode: "active",
                }}
                validationSchema={validationSchema}
                onSubmit={(values, { resetForm }) => {
                  handleSubmit(values, resetForm);
                }}
              >
                {({ errors, touched, handleSubmit, setFieldValue }) => (
                  <Form onSubmit={handleSubmit}>
                    <FormItem
                      label="Position ID"
                      validateStatus={
                        errors.PositionID && touched.PositionID ? "error" : ""
                      }
                      help={
                        errors.PositionID && touched.PositionID
                          ? errors.PositionID
                          : ""
                      }
                    >
                      <Field name="PositionID">
                        {({ field }) => (
                          <Select
                            {...field}
                            onChange={(value) =>
                              setFieldValue("PositionID", value)
                            }
                            className="custom-input"
                          >
                            <Option value="1">1</Option>
                            <Option value="2">2</Option>
                            <Option value="3">3</Option>
                          </Select>
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Position Name"
                      validateStatus={
                        errors.PositionName && touched.PositionName
                          ? "error"
                          : ""
                      }
                      help={
                        errors.PositionName && touched.PositionName
                          ? errors.PositionName
                          : ""
                      }
                    >
                      <Field name="PositionName">
                        {({ field }) => (
                          <Input {...field} className="custom-input" />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Department ID"
                      validateStatus={
                        errors.DepartmentID && touched.DepartmentID
                          ? "error"
                          : ""
                      }
                      help={
                        errors.DepartmentID && touched.DepartmentID
                          ? errors.DepartmentID
                          : ""
                      }
                    >
                      <Field name="DepartmentID">
                        {({ field }) => (
                          <Select
                            {...field}
                            className="custom-input"
                            onChange={(value) =>
                              setFieldValue("DepartmentID", value)
                            }
                          >
                            <Option value="18">18</Option>
                            <Option value="19">19</Option>
                          </Select>
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Basic Salary"
                      validateStatus={
                        errors.BasicSalary && touched.BasicSalary ? "error" : ""
                      }
                      help={
                        errors.BasicSalary && touched.BasicSalary
                          ? errors.BasicSalary
                          : ""
                      }
                    >
                      <Field name="BasicSalary">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Contract Template Path"
                      validateStatus={
                        errors.ContractTemplatePath &&
                        touched.ContractTemplatePath
                          ? "error"
                          : ""
                      }
                      help={
                        errors.ContractTemplatePath &&
                        touched.ContractTemplatePath
                          ? errors.ContractTemplatePath
                          : ""
                      }
                    >
                      <Field name="ContractTemplatePath">
                        {({ field }) => (
                          <Input {...field} className="custom-input" />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="First Hike Period"
                      validateStatus={
                        errors.FirstHikePeriod && touched.FirstHikePeriod
                          ? "error"
                          : ""
                      }
                      help={
                        errors.FirstHikePeriod && touched.FirstHikePeriod
                          ? errors.FirstHikePeriod
                          : ""
                      }
                    >
                      <Field name="FirstHikePeriod">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="First Hike Amount"
                      validateStatus={
                        errors.FirstHikeAmount && touched.FirstHikeAmount
                          ? "error"
                          : ""
                      }
                      help={
                        errors.FirstHikeAmount && touched.FirstHikeAmount
                          ? errors.FirstHikeAmount
                          : ""
                      }
                    >
                      <Field name="FirstHikeAmount">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Second Hike Period"
                      validateStatus={
                        errors.SecondHikePeriod && touched.SecondHikePeriod
                          ? "error"
                          : ""
                      }
                      help={
                        errors.SecondHikePeriod && touched.SecondHikePeriod
                          ? errors.SecondHikePeriod
                          : ""
                      }
                    >
                      <Field name="SecondHikePeriod">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Second Hike Amount"
                      validateStatus={
                        errors.SecondHikeAmount && touched.SecondHikeAmount
                          ? "error"
                          : ""
                      }
                      help={
                        errors.SecondHikeAmount && touched.SecondHikeAmount
                          ? errors.SecondHikeAmount
                          : ""
                      }
                    >
                      <Field name="SecondHikeAmount">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Third Hike Period"
                      validateStatus={
                        errors.ThirdHikePeriod && touched.ThirdHikePeriod
                          ? "error"
                          : ""
                      }
                      help={
                        errors.ThirdHikePeriod && touched.ThirdHikePeriod
                          ? errors.ThirdHikePeriod
                          : ""
                      }
                    >
                      <Field name="ThirdHikePeriod">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Third Hike Amount"
                      validateStatus={
                        errors.ThirdHikeAmount && touched.ThirdHikeAmount
                          ? "error"
                          : ""
                      }
                      help={
                        errors.ThirdHikeAmount && touched.ThirdHikeAmount
                          ? errors.ThirdHikeAmount
                          : ""
                      }
                    >
                      <Field name="ThirdHikeAmount">
                        {({ field }) => (
                          <Input
                            type="number"
                            {...field}
                            className="custom-input"
                          />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem
                      label="Status Code"
                      validateStatus={
                        errors.StatusCode && touched.StatusCode ? "error" : ""
                      }
                      help={
                        errors.StatusCode && touched.StatusCode
                          ? errors.StatusCode
                          : ""
                      }
                    >
                      <Field name="StatusCode">
                        {({ field }) => (
                          <Input {...field} className="custom-input" />
                        )}
                      </Field>
                    </FormItem>

                    <FormItem className="text-center">
                      <Button
                        type="primary"
                        htmlType="submit"
                        className="w-50"
                        disabled={loading === "pending" ? true : false}
                      >
                        {loading === "pending" ? "loading..." : "Submit"}
                      </Button>
                    </FormItem>
                  </Form>
                )}
              </Formik>
            </Col>
          </Row>
        </Container>
      </Card>
    </>
  );
};

export default AddPosItionMaster;