import { PlusOutlined } from "@ant-design/icons";
import { Card } from "antd";
import Button from "antd-button-color";
import { useEffect, useState } from "react";
import { MasterTable } from "../../components";
import { COLUMNS } from "./helper/colums";
import { getPositions } from "../../store/slices/User/userApi";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

function PostionMaster() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const { loading } = useSelector((state) => state.user);

  useEffect(() => {
    fetchPositions();
  }, []);

  const fetchPositions = () => {
    const data = {
      apiEndpoint: "/v1/api/Positions/?page=1&itemsPerPage=100&orderBy=Id|DESC",
    };
    dispatch(getPositions(data)).then((res) => {
      if (res.type === "getPositions/fulfilled") {
        setData(res.payload.document.records);
      }
    });
  };
  return (
    <>
      <Card
        bordered={false}
        className="bg-white py-2 px-2 cardHeaderBorderNone"
        extra={
          <>
            <Button
              className="min-w-[180px] border !border-[#D5D5D5]"
              type="secondary"
              icon={<PlusOutlined />}
              onClick={() => navigate("/add-position-master")}
            >
              Add Position
            </Button>
          </>
        }
      >
        <MasterTable
          loading={loading === "pending" ? true : false}
          tableHead={COLUMNS}
          TableData={data}
        />
      </Card>
    </>
  );
}

export default PostionMaster;
