import React, { useState } from "react";
import { Divider, Typography, Tabs, Row, Col, Card } from "antd";
import { AndroidOutlined, AppleOutlined } from "@ant-design/icons";
import { FaListUl } from "react-icons/fa6";
import { FiPlus } from "react-icons/fi";
const { Title } = Typography;

const items = [
  {
    key: "1",
    label: "Basic details",
    children: "Basic details content",
  },
  {
    key: "2",
    label: "Document",
    children: "Document content",
  },
];
const itemsIcon = [
  {
    key: "1",
    label: "Andriod",
    icon: <AndroidOutlined />,
    children: "Andriod content",
  },
  {
    key: "2",
    label: "Apple",
    icon: <AppleOutlined />,
    children: "Apple content",
  },
];

const itemsTabCard = [
  {
    key: "1",
    label: "Customer listing",
    icon: <FaListUl />,
    children: "Customer listing content...",
  },
  {
    key: "2",
    label: "Add Customer",
    icon: <FiPlus />,
    children: "Add Customer content...",
  },
];

function TabCom() {
  return (
    <>
      <div className="p-4">
        <Row justify="center">
          <Col span={22}>
            <Card
              className="w-full text-dark-100 bg-white"
              title="Tabs component"
              bordered={false}
            >
              <Tabs
                className="defaultTabsComponent"
                centered
                defaultActiveKey="1"
                items={items}
              />
              <div className="mt-4">
                <Tabs
                  className="defaultTabsComponent"
                  centered
                  defaultActiveKey="1"
                  items={items}
                  tabPosition="left"
                />
              </div>
            </Card>
          </Col>
        </Row>
      </div>
      {/* <div>
        <Divider>
          <Title className="!text-gray-500 !text-sm" level={5}>
            With icon tab
          </Title>
        </Divider>
        <Tabs defaultActiveKey="1" items={itemsIcon} />
      </div>
      <div>
        <Divider>
          <Title className="!text-gray-500 !text-sm" level={5}>
            With card tab
          </Title>
        </Divider>
        <Tabs
          className="customTabComponent"
          defaultActiveKey="1"
          type="card"
          items={itemsTabCard}
        />
      </div> */}
    </>
  );
}

export default TabCom;
