import React, { useState } from "react";
import { Divider, Typography, Table, Row, Col, Card } from "antd";
import { columnTable } from "./helper/TableColum";
import { MasterTable } from "../../components";
import MockData from "./helper/MOCK_DATA.json";
const { Title } = Typography;
const dataSource = [
  {
    key: "1",
    name: "Mike",
    age: 32,
    address: "10 Downing Street",
  },
  {
    key: "2",
    name: "John",
    age: 42,
    address: "10 Downing Street",
  },
];
const columns = [
  {
    title: "Name",
    dataIndex: "name",
    key: "name",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Address",
    dataIndex: "address",
    key: "address",
  },
];

function TableCom() {
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const onSelectChange = (newSelectedRowKeys) => {
    console.log("selectedRowKeys changed: ", newSelectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };
  return (
    <>
      <div className="p-4">
        <Row justify="center">
          <Col span={22}>
            <Card
              className="w-full text-dark-100 bg-white"
              title="Table component"
              bordered={false}
            >
              <div className="mb-20">
                <MasterTable
                  loading={false}
                  tableHead={columnTable}
                  TableData={MockData}
                />
              </div>

              <div>
                <Divider>
                  <Title className="!text-gray-500 !text-sm" level={5}>
                    Basic table
                  </Title>
                </Divider>
                <Table dataSource={dataSource} columns={columns} />
              </div>
              <div>
                <Divider>
                  <Title className="!text-gray-500 !text-sm" level={5}>
                    Selection table
                  </Title>
                </Divider>
                <Table
                  rowSelection={rowSelection}
                  dataSource={dataSource}
                  columns={columns}
                />
              </div>
              <div>
                <Divider>
                  <Title className="!text-gray-500 !text-sm" level={5}>
                    Fixed header
                  </Title>
                </Divider>
                <Table
                  showSorterTooltip={{
                    target: "sorter-icon",
                  }}
                  scroll={{
                    y: 100,
                  }}
                  rowSelection={rowSelection}
                  dataSource={dataSource}
                  columns={columns}
                />
              </div>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default TableCom;
