import React from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import multiMonthPlugin from "@fullcalendar/multimonth";
import { INITIAL_EVENTS, createEventId } from "../../utils/helper";
function Calendar() {
  return (
    <>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, multiMonthPlugin]}
        initialView="dayGridMonth"
        headerToolbar={{
          left: "",
          center: "prev,title,next",
          right: "timeGridDay,dayGridWeek,dayGridMonth,multiMonthYear",
        }}
        initialEvents={INITIAL_EVENTS}
        eventClick={(e) => console.log(e.event.title)}
      />
    </>
  );
}

export default Calendar;
