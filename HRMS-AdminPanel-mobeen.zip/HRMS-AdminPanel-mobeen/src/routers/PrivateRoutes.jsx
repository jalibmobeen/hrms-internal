import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export function PrivateRoute({ Component, props }) {
  const { token } = useSelector((state) => state.user);

  if (token === null) {
    return <Navigate to={"/"} />;
  } else {
    return <Component {...props} />;
  }
}
