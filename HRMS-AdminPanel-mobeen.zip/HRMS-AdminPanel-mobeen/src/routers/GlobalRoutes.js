import { lazy } from "react";
const GlobalRoutes = [
  {
    path: "/",
    component: lazy(() => import("../pages/Auth/SignIn")),
    exact: true,
    isPublic: true,
    childRouters: [],
  },
  {
    path: "/forgot-password",
    component: lazy(() => import("../pages/Auth/ForgotPassword")),
    exact: true,
    isPublic: true,
    childRouters: [],
  },
  {
    path: "/verify-otp",
    component: lazy(() => import("../pages/Auth/VerifyOtp")),
    exact: true,
    isPublic: true,
    childRouters: [],
  },
  {
    path: "/reset-password",
    component: lazy(() => import("../pages/Auth/ResetPassword")),
    exact: true,
    isPublic: true,
    childRouters: [],
  },
  {
    path: "/dashboard",
    component: lazy(() => import("../pages/home/Index")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },
  {
    path: "/add-position-master",
    component: lazy(() => import("../pages/Masters/AddPositionMaster")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },
  {
    path: "/staff-listing",
    component: lazy(() => import("../pages/StaffManagement/StaffListing")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },
  {
    path: "/position-master",
    component: lazy(() => import("../pages/Masters/PositionMaster")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },

  {
    path: "announcement-master",
    component: lazy(() => import("../pages/AnnoucementMaster/Index")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },
  {
    path: "/components",
    component: lazy(() => import("../pages/Ui/Index")),
    exact: true,
    isPublic: false,
    childRouters: [],
  },
  // {
  //   path: "/component",
  //   component: lazy(() => import("../pages/Ui/Main")),
  //   exact: true,
  //   childRouters: [
  //     {
  //       cpath: "button",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/ButtonCom")),
  //     },
  //     {
  //       cpath: "form",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/FormCom")),
  //     },
  //     {
  //       cpath: "table",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/TableCom")),
  //     },
  //     {
  //       cpath: "calendar",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/Calendar")),
  //     },
  //     {
  //       cpath: "tab",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/TabCom")),
  //     },
  //     {
  //       cpath: "divider",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/DividerCom")),
  //     },
  //     {
  //       cpath: "carousel",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/CarouselCom")),
  //     },
  //     {
  //       cpath: "empty",
  //       exact: true,
  //       component: lazy(() => import("../pages/Ui/EmptyCom")),
  //     },
  //   ],
  // },
];
export default GlobalRoutes;
