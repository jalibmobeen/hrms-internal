import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export function PublicRoute({ Component, props }) {
  const { token } = useSelector((state) => state.user);

  if (token) {
    return <Navigate to={"/dashbord"} replace={true} />;
  } else {
    return <Component {...props} />;
  }
}
