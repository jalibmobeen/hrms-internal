import React, { Suspense, useState, useEffect } from "react";
import { MenuFoldOutlined, MenuUnfoldOutlined } from "@ant-design/icons";
import { Layout, Button, Breadcrumb, Drawer } from "antd";
import { AppHeader, SideBarCom } from "./components";
import {
  Link,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import PublicRoutes from "./routers/PublicRoute";

const { Header, Content } = Layout;

const App = () => {
  const location = useLocation();
  const navigate = useNavigate();
  // all authentication logic
  const isAuthenticated = false;
  console.log(isAuthenticated);

  useEffect(() => {
    if (!isAuthenticated) {
    } else if (location.pathname == "/login") {
      navigate("/");
    }
  }, [location]);

  const [collapsed, setCollapsed] = useState(false);
  const [responsiveSide, setresponsiveSide] = useState(false);
  const onClose = () => {
    setCollapsed(false);
  };

  return (
    <Suspense>
      <Layout
        className={`min-h-screen ${
          !collapsed && responsiveSide ? "overlayShow" : ""
        }`}
        hasSider={false}
      >
        {/* sidebar */}
        <SideBarCom
          collapsed={collapsed}
          setCollapsed={setCollapsed}
          responsiveSide={responsiveSide}
          setresponsiveSide={setresponsiveSide}
        />

        {/* <Layout className="bg-gradient-to-r from-white via-[rgba(243,227,244,0.12)] to-[#8ccdf567]"> */}
        {/* <Layout className="bg-gradient-to-r from-[#FFFFFF] from-30% via-[#F3E3F4] via-70% to-[#8CCDF5] to-90%"> */}
        <Layout
          className={`bg-gradient-to-r from-[#8ccdf52c] from-10% via-[#f3e3f452] via-50% to-[#FFFFFF] to-90% layoutWrap ${
            collapsed ? "desktop-mini" : ""
          } ${responsiveSide ? "mobile-side" : ""}`}
          // style={{
          //   marginLeft: collapsed ? 80 : 270,
          // }}
        >
          {/* app header */}
          <AppHeader
            collapsed={collapsed}
            setCollapsed={setCollapsed}
            title={"Appointments"}
          />
          <Content className="px-4 py-3">
            <Routes>
              {PublicRoutes.map(({ component: Component, path, exact }) => (
                <Route
                  path={`/${path}`}
                  key={path}
                  exact={exact}
                  element={<Component />}
                />
              ))}
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </Suspense>
  );
};
export default App;
