import LogoIcon from "../assets/images/logo.svg";
import StaffIcon from "../assets/images/icons/StaffIcon.svg";
import HomeIcon from "../assets/images/icons/homeIcon.svg";
import MastersIcon from "../assets/images/icons/mastersIcon.svg";
import AuthShape from "../assets/images/authShape.png";
import CarImage from "../assets/images/car-image.png";
import CarImage2 from "../assets/images/car-image-2.png";
export {
  LogoIcon,
  AuthShape,
  CarImage,
  CarImage2,
  StaffIcon,
  HomeIcon,
  MastersIcon,
};
