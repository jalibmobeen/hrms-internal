import { Suspense, useState } from "react";
import { Layout } from "antd";
import { AppHeader, SideBarCom } from "./components";
import "./App.css";
import {
  Outlet,
  Route,
  Routes,
} from "react-router-dom";
import { Container } from "react-bootstrap";

import NoFoundComponent from "./pages/Error/404";
import GlobalRoutes from "./routers/GlobalRoutes";
import { PrivateRoute } from "./routers/PrivateRoutes";
import { PublicRoute } from "./routers/PublicRoutes";
import { useSelector } from "react-redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const { Header, Content } = Layout;

function BasicLayout(props) {
  const { token } = useSelector((state) => state.user);
  const [collapsed, setCollapsed] = useState(false);
  const [responsiveSide, setresponsiveSide] = useState(false);
  const onClose = () => {
    setCollapsed(false);
  };
  return (
    <>
      {token && (
        <>
          <ToastContainer />
          <Layout
            className={`min-h-screen ${
              !collapsed && responsiveSide ? "overlayShow" : ""
            }`}
            hasSider={false}
          >
            {/* sidebar */}
            <SideBarCom
              collapsed={collapsed}
              setCollapsed={setCollapsed}
              responsiveSide={responsiveSide}
              setresponsiveSide={setresponsiveSide}
            />
            <Layout
              className={`bg-gradient-to-r from-[#8ccdf52c] from-10% via-[#f3e3f452] via-50% to-[#FFFFFF] to-90% layoutWrap ${
                collapsed ? "desktop-mini" : ""
              } ${responsiveSide ? "mobile-side" : ""}`}
              // style={{
              //   marginLeft: collapsed ? 80 : 270,
              // }}
            >
              {/* app header */}
              <AppHeader
                collapsed={collapsed}
                setCollapsed={setCollapsed}
                title={"Appointments"}
              />
              <Content className="px-4 py-3">
                <Outlet />
              </Content>
            </Layout>
          </Layout>
        </>
      )}
      {token === null && (
        <>
          <ToastContainer />
          <Container fluid>
            <Outlet />
          </Container>
        </>
      )}
    </>
  );
}

const App = () => {
  return (
    <Suspense>
      <Routes>
        <Route path="/" element={<BasicLayout />}>
          {GlobalRoutes.map(
            ({ component: Component, path, exact, childRouters, isPublic }) => {
              return (
                <Route
                  path={`/${path}`}
                  key={path}
                  exact={exact}
                  element={
                    <>
                      {!isPublic ? (
                        <PrivateRoute Component={Component} />
                      ) : (
                        <PublicRoute Component={Component} />
                      )}
                    </>
                  }
                ></Route>
              );
            }
          )}
          <Route path="*" element={<NoFoundComponent />} />
        </Route>
      </Routes>
    </Suspense>
  );
};
export default App;
